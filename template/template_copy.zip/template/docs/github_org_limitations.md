# GitHub Org Limitations

There are several template features that are intentionally excluded for repositores made under GitHub organizations, detailed below:

## Repo Settings

* `Auto-merge for pull requests` is not set as it might conflict with org policies
* `Delete branch on merge` is not set as it would require organization owner rights to set